<?php 
/**
 Template Name: About
 Displays Only About Template

 *@package Wordpress
 * @subpackage webite
 * @since website 1.0
*/
get_header();

?>
<div class="About">

  <div class="container-fluid">

    <div class="row">
      <div class="col-md-12">
        
        <p>About Us</p>
      </div>
      
        
        

    </div>
  </div>
</div>


  <div class="container-fluid">
    <div class="row">
      <div class="my-heading_about">
        <h1>WHO WE ARE</h1>
      </div>
    </div>
    <div class="row">
      <div class="Who-content">
        <p><span>ALFATEC LIMITED</span> was founded in 2017 located in Dhaka at Uttara. It is developed rapidly through advance 
Technologyand professional levels in the field of material handling equipment.

<span>ALFATEC LIMITED</span> is a comprehensive enterprise integrated production and Supply, professionally 
Manufacturing Industrial Racking System. Our company constantly improves the production
And updates technology to meet the growing increasingly labour market. We have more than 50 models of
Material handling equipment.The main Products: Forklift, Hand Pallet Truck, Reach Truck, Articulated Forklift, Hand Stacker, Electric Pallet Truck, Drum Lifter, Hydraulic Scissor lift, Industrial Furniture,all kind of Filters and so on. The sales and post sales network cover all over Bangladesh.

Our company aims not only at meeting the customer’s needs,together with all our staff, contributes our all to improving logistics industry efficiency with the responsibility of creating your benefits by using our products.
</p>
      </div>
    </div>
  </div>

 <?php get_footer();?>



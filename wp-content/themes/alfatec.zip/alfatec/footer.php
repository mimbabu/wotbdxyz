<!-- Footer Start -->
<div class="special-footer-my">
<div class="container-fluid">

	<div class="row">
		<div class="col-md-4">
			<div class="my-footer-heading">
				<h5>ALFATEC LIMITED</h5>
				
			</div>
			<ul>
					<li>Corporate Office</li>
					<li>House#13 (4th Floor)</li>
					<li>Road # 3-F,Sector # 09, Uttara</li>
					<li>Dhaka-1230,Bangladesh</li>
					<li><a href="">+88-02-48955512</a></li>
					<li><a href="">info@alfateclimited.com</a></li>
					<li><a href="www.alfateclimited.com">www.alfateclimited.com</a></li>
				</ul>
		</div>
<div class="col-md-4">
   <div class="my-footer-heading">
			<h5>PRODUCTS</h5>
			</div>

			<ul>
				<li><a href="forklift.php">Material Handling Equipments</a></li>
			    <li><a href="#">Industrial Racking System</a></li>
		        <li><a href="product.php">All types of Filter</a></li>
		       <li><a href="#">Hoist & overhead Crane</a></li>
		      <li><a href="#">Service and Spare Parts</a></li>
		      </ul>
		</div>
		
		<div class="col-md-4">
			<div class="my-footer-heading">
				<h5>FOLLOW US </h5>
			</div>
			<div class="social-icon">
			<div class="row">
			    <div class="col-md-2"><i class="fab fa-facebook"></i></div>
				<div class="col-md-2"><i class="fab fa-twitter"></i></div>
				<div class="col-md-2"><i class="fab fa-youtube"></i></div>
				<div class="col-md-2"><i class="fab fa-linkedin-in"></i></div>
			    <div class="col-md-2"></div>
				<div class="col-md-2"></div>
			</div>
			</div>
			
		</div>

	</div>
   </div>
</div>


<!-- End -->




<?php 
/**
 Template Name: SELF PROPELLED SCISSOR LIFT
 Displays Only SELF PROPELLED SCISSOR LIFT Template

 *@package Wordpress
 * @subpackage webite
 * @since website 1.0
*/
get_header();

?>



<div class="container">
    <div class="row">
        <div class="col-md-12">
          <div class="warehouse-heading">
            <h4> SELF PROPELLED SCISSOR LIFT</h4>
            </div>
        </div>
    </div>
</div>





<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="disel">
                <h1> SELF PROPELLED SCISSOR LIFT</h1>
            </div>
            <h1></h1>
        </div>
    </div>
</div>




<div class="Self_propled_scissorlift">

<div class="container">
  
  <div class="row">
    <div class="col-md-6">
<div class="Forklift-part">
<div class="container">
  <div class="row">
    <div class="image">
      <img src="<?php echo get_template_directory_uri();?>/img/SELF PROPELLED SCISSOR LIFT sm.jpg">
    </div>
    <div class="img-head">
      <h4>SELF PROPELLED SCISSOR LIFT</h4>
    </div>
    </div>
    <div class="container-fluid">
      <hr>
      <div class="below-row">
      <div class="row">
        
        <div class="col-sm-6"><a href="" >See more</a></div>
       <div class="col-sm-6"><div class="arrow_product">
       <i class="fas fa-arrow-right"></i>
       
       </div>
       </div>
       </div>
      </div>
    </div>
</div>
</div>
</div>
     <div class="col-md-6">
       <div class="Forklift-part">
<div class="container">
  <div class="row">
    <div class="image">
      <img src="<?php echo get_template_directory_uri();?>/img/SELF PROPELLED SCISSOR LIFT-sm1.jpg">
    </div>
    <div class="img-head">
      <h4>SELF PROPELLED SCISSOR LIFT</h4>
    </div>
    </div>
    <div class="container-fluid">
      <hr>
      <div class="below-row">
      <div class="row">
        
        <div class="col-sm-6"><a href="" >See more</a></div>
       <div class="col-sm-6"><div class="arrow_product">
       <i class="fas fa-arrow-right"></i>
       
       </div>
       </div>
       </div>
      </div>
    </div>
</div>
</div>
</div>
      
  




    </div>
</div>

</div>



<script type="text/javascript" src="<?php echo get_template_directory_uri();?>/js/all.min.js"></script>
<?php get_footer();?>